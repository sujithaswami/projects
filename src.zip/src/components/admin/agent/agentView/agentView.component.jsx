export function AgentView(){
    const header=["AgentName","AgentEmail","AgentPhonenumber","Agent"]
    return(
        <div>

        </div>
    )
}